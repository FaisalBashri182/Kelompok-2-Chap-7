package  tsm.bdg.ch6group

interface CallBack {
    fun showResult (result: String)
}