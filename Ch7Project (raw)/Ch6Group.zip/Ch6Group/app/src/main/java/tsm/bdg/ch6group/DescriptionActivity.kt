package tsm.bdg.ch6group

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DescriptionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
    }
}